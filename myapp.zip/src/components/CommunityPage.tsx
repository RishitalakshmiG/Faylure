import { useState } from 'react'
import { Card, CardContent } from './ui/card'
import { Button } from './ui/button'
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar'
import { Badge } from './ui/badge'
import { Search, TrendingUp, Users, Award, MessageCircle } from 'lucide-react'
import { Input } from './ui/input'

// Mock community data
const trendingTopics = [
  { tag: '#StartupFailures', posts: 234 },
  { tag: '#CareerMistakes', posts: 189 },
  { tag: '#LeadershipLessons', posts: 156 },
  { tag: '#ProductLaunches', posts: 134 },
  { tag: '#HiringMistakes', posts: 98 }
]

const topContributors = [
  {
    name: 'Sarah Chen',
    title: 'Product Manager',
    avatar: 'https://images.unsplash.com/photo-1585554414787-09b821c321c0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHdvbWFuJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1ODQ2NTY5NXww&ixlib=rb-4.1.0&q=80&w=400',
    storiesShared: 24,
    helpfulReactions: 456
  },
  {
    name: 'Marcus Johnson',
    title: 'Software Engineer',
    avatar: 'https://images.unsplash.com/photo-1524538198441-241ff79d153b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHByb2Zlc3Npb25hbCUyMG1hbGV8ZW58MXx8fHwxNzU4NDcyMjgxfDA&ixlib=rb-4.1.0&q=80&w=400',
    storiesShared: 18,
    helpfulReactions: 389
  },
  {
    name: 'Alex Rivera',
    title: 'Marketing Director',
    avatar: 'https://images.unsplash.com/photo-1576558656222-ba66febe3dec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdCUyMHBvcnRyYWl0fGVufDF8fHx8MTc1ODQ0NTk4NHww&ixlib=rb-4.1.0&q=80&w=400',
    storiesShared: 15,
    helpfulReactions: 342
  }
]

const discussions = [
  {
    id: '1',
    title: 'How do you bounce back from a major project failure?',
    author: 'Jennifer Walsh',
    replies: 23,
    lastActive: '2 hours ago',
    tags: ['#Resilience', '#ProjectManagement']
  },
  {
    id: '2',
    title: 'Worst hiring decisions and what we learned',
    author: 'David Kim',
    replies: 45,
    lastActive: '4 hours ago',
    tags: ['#HiringMistakes', '#Leadership']
  },
  {
    id: '3',
    title: 'When your "brilliant" idea completely flops',
    author: 'Maria Santos',
    replies: 18,
    lastActive: '6 hours ago',
    tags: ['#Innovation', '#ProductFails']
  }
]

export function CommunityPage() {
  const [activeTab, setActiveTab] = useState<'trending' | 'contributors' | 'discussions'>('trending')
  const [searchQuery, setSearchQuery] = useState('')

  return (
    <div className="min-h-screen bg-pink-50 pb-20 text-black">
      {/* Header */}
      <div className="bg-pink-50 border-b border-pink-200 px-4 py-4 sticky top-0 z-30">
        <h1 className="text-xl font-semibold mb-3">Community</h1>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-pink-400" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search stories, topics, or people..."
            className="pl-10 bg-pink-50 border-pink-200 text-black placeholder-pink-400"
          />
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-pink-50 border-b border-pink-200 px-4">
        <div className="flex space-x-6">
          <button
            onClick={() => setActiveTab('trending')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'trending' 
                ? 'border-pink-500 text-pink-600' 
                : 'border-transparent text-pink-600/70'
            }`}
          >
            Trending
          </button>
          <button
            onClick={() => setActiveTab('contributors')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'contributors' 
                ? 'border-pink-500 text-pink-600' 
                : 'border-transparent text-pink-600/70'
            }`}
          >
            Top Contributors
          </button>
          <button
            onClick={() => setActiveTab('discussions')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'discussions' 
                ? 'border-pink-500 text-pink-600' 
                : 'border-transparent text-pink-600/70'
            }`}
          >
            Discussions
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-6">
        {activeTab === 'trending' && (
          <div className="space-y-6">
            {/* Community Stats */}
            <Card className="bg-pink-50 border-pink-200 text-black">
              <CardContent className="p-4">
                <h3 className="font-medium mb-3">Community Insights</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-pink-100 rounded-lg">
                    <div className="text-2xl font-semibold text-pink-600">1,247</div>
                    <div className="text-sm">Stories Shared</div>
                  </div>
                  <div className="text-center p-3 bg-pink-100 rounded-lg">
                    <div className="text-2xl font-semibold text-pink-600">3,891</div>
                    <div className="text-sm">Lessons Learned</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Trending Topics */}
            <Card className="bg-pink-50 border-pink-200 text-black">
              <CardContent className="p-4">
                <div className="flex items-center mb-3">
                  <TrendingUp className="w-5 h-5 text-pink-600 mr-2" />
                  <h3 className="font-medium">Trending Topics</h3>
                </div>
                <div className="space-y-3">
                  {trendingTopics.map((topic, index) => (
                    <div key={topic.tag} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center text-sm font-medium">
                          {index + 1}
                        </div>
                        <span className="font-medium text-pink-600">{topic.tag}</span>
                      </div>
                      <span className="text-sm text-pink-600/80">{topic.posts} posts</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Weekly Challenge */}
            <Card className="bg-pink-50 border-pink-200 text-black">
              <CardContent className="p-4">
                <div className="flex items-center mb-2">
                  <Award className="w-5 h-5 text-pink-600 mr-2" />
                  <h3 className="font-medium">Weekly Challenge</h3>
                </div>
                <p className="mb-3">
                  Share a time when you had to admit you were wrong in front of your team. How did it go?
                </p>
                <Button className="bg-pink-600 hover:bg-pink-700 text-white">
                  Join Challenge
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'contributors' && (
          <div className="space-y-4">
            <p className="text-sm text-pink-600/70 mb-4">
              Recognizing those who share their vulnerabilities to help others grow
            </p>
            
            {topContributors.map((contributor, index) => (
              <Card key={contributor.name} className="bg-pink-50 border-pink-200 text-black">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={contributor.avatar} alt={contributor.name} />
                        <AvatarFallback>{contributor.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      {index < 3 && (
                        <div className="absolute -top-1 -right-1 w-6 h-6 bg-pink-600 text-white rounded-full flex items-center justify-center text-xs font-medium">
                          {index + 1}
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <h4 className="font-medium">{contributor.name}</h4>
                      <p className="text-sm text-black/70">{contributor.title}</p>
                      
                      <div className="flex items-center space-x-4 mt-2 text-black/70">
                        <span className="text-sm">{contributor.storiesShared} stories</span>
                        <span className="text-sm">{contributor.helpfulReactions} helpful reactions</span>
                      </div>
                    </div>
                    
                    <Button variant="outline" size="sm" className="border-pink-600 text-pink-600 hover:bg-pink-50">
                      Follow
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {activeTab === 'discussions' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-pink-600/70">
                Open conversations about learning from failure
              </p>
              <Button className="bg-pink-600 hover:bg-pink-700 text-white">
                Start Discussion
              </Button>
            </div>
            
            {discussions.map((discussion) => (
              <Card key={discussion.id} className="bg-pink-50 border-pink-200 text-black">
                <CardContent className="p-4">
                  <h4 className="font-medium mb-2">{discussion.title}</h4>
                  
                  <div className="flex items-center space-x-2 mb-3">
                    {discussion.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs text-pink-600">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-pink-600/70">
                    <span>Started by {discussion.author}</span>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <MessageCircle className="w-4 h-4 text-pink-600" />
                        <span>{discussion.replies}</span>
                      </div>
                      <span>{discussion.lastActive}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
