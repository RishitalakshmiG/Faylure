import { Home, Edit3, Users, User } from 'lucide-react'

interface NavigationBarProps {
  activeTab: 'home' | 'write' | 'community' | 'profile'
  onTabChange: (tab: 'home' | 'write' | 'community' | 'profile') => void
}

export function NavigationBar({ activeTab, onTabChange }: NavigationBarProps) {
  const tabs = [
    { id: 'home' as const, icon: Home, label: 'Home' },
    { id: 'write' as const, icon: Edit3, label: 'Write' },
    { id: 'community' as const, icon: Users, label: 'Community' },
    { id: 'profile' as const, icon: User, label: 'Profile' }
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-pink-50 border-t border-pink-200 z-50">
      <div className="flex justify-around py-2">
        {tabs.map((tab) => {
          const Icon = tab.icon
          const isActive = activeTab === tab.id

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className="flex flex-col items-center bg-transparent p-0 m-0 rounded-none focus:outline-none hover:bg-transparent active:bg-transparent"
            >
              <Icon
                stroke="currentColor"
                className={`w-6 h-6 ${isActive ? 'text-pink-600' : 'text-pink-600/50'}`}
              />
              <span className={`text-xs ${isActive ? 'text-pink-600' : 'text-pink-600/50'}`}>
                {tab.label}
              </span>
            </button>
          )
        })}
      </div>
    </div>
  )
}



