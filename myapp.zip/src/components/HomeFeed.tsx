import { useState } from 'react'
import { PostCard } from './PostCard'
import faylureLogo from 'figma:asset/82b02838ae1839fddf6d6de1560e9d4a8778a723.png'

// Mock data for demonstration
const mockPosts = [
  {
    id: '1',
    author: {
      name: 'Sarah Chen',
      title: 'Product Manager at TechCorp',
      avatar: 'https://images.unsplash.com/photo-1585554414787-09b821c321c0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHdvbWFuJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1ODQ2NTY5NXww&ixlib=rb-4.1.0&q=80&w=400'
    },
    content: "Last month I launched a feature that I was absolutely convinced would be a game-changer. Spent 3 months building it, got buy-in from leadership, and... it flopped completely. Users didn't engage with it at all. I felt like I had wasted everyone's time and resources.",
    lessonLearned: "I realized I fell in love with my own idea instead of validating it with real users first. Now I always start with user interviews and prototype testing before building anything substantial.",
    timeAgo: '2 hours ago',
    reactions: { resilient: 124, lesson: 89, support: 45 },
    comments: 23
  },
  {
    id: '2',
    author: {
      name: 'Marcus Johnson',
      title: 'Software Engineer at StartupXYZ',
      avatar: 'https://images.unsplash.com/photo-1524538198441-241ff79d153b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHByb2Zlc3Npb25hbCUyMG1hbGV8ZW58MXx8fHwxNzU4NDcyMjgxfDA&ixlib=rb-4.1.0&q=80&w=400'
    },
    content: "I accidentally deleted our entire staging database during a routine deployment. Yes, the ENTIRE database. Had to tell my team, our CTO, and delay our product launch by a week while we restored from backups.",
    lessonLearned: "Always double-check your environment variables. Also, implement better safeguards and confirmation steps for destructive operations. The team was surprisingly supportive though!",
    timeAgo: '5 hours ago',
    reactions: { resilient: 256, lesson: 134, support: 78 },
    comments: 41
  },
  {
    id: '3',
    author: {
      name: 'Alex Rivera',
      title: 'Marketing Director at GrowthCo',
      avatar: 'https://images.unsplash.com/photo-1576558656222-ba66febe3dec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdCUyMHBvcnRyYWl0fGVufDF8fHx8MTc1ODQ0NTk4NHww&ixlib=rb-4.1.0&q=80&w=400'
    },
    content: "Pitched what I thought was a brilliant campaign to our biggest client. They not only rejected it, they questioned our entire strategy and threatened to end the contract. I was devastated and questioning my abilities.",
    lessonLearned: "Sometimes failure is about timing and fit, not just quality. We regrouped, listened more carefully to their concerns, and came back with something that addressed their real needs. They're now our longest-running client.",
    timeAgo: '1 day ago',
    reactions: { resilient: 89, lesson: 156, support: 92 },
    comments: 18
  }
]

interface HomeFeedProps {
  onWritePost: () => void
}

export function HomeFeed({ onWritePost }: HomeFeedProps) {
  const [posts, setPosts] = useState(mockPosts)

  const handleReaction = (postId: string, type: 'resilient' | 'lesson' | 'support') => {
    setPosts(prevPosts => 
      prevPosts.map(post => 
        post.id === postId 
          ? { ...post, reactions: { ...post.reactions, [type]: post.reactions[type] + 1 } }
          : post
      )
    )
  }

  return (
    <div className="pb-20 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-30">
        <div className="flex items-center justify-between">
          <img 
            src={faylureLogo} 
            alt="Faylure Logo" 
            className="w-12 h-12 object-contain"
          />
          <h1 className="text-xl font-semibold text-gray-900 absolute left-1/2 transform -translate-x-1/2">Faylure</h1>
          <div className="w-12"></div> {/* Spacer for balance */}
        </div>
      </div>

      {/* Feed */}
      <div className="pt-4">
        {posts.map(post => (
          <PostCard
            key={post.id}
            post={post}
            onSwipeRight={onWritePost}
            onReaction={(type) => handleReaction(post.id, type)}
          />
        ))}
      </div>

      {/* Loading indicator or end of feed message */}
      <div className="text-center py-8 text-gray-500">
        <p>You're all caught up! Share your own story.</p>
      </div>
    </div>
  )
}