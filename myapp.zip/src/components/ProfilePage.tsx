import { useState } from 'react'
import { Button } from './ui/button'
import { Card, CardContent } from './ui/card'
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar'
import { Badge } from './ui/badge'
import { Settings, Edit3, Calendar, TrendingUp, Users, Flame, Lightbulb, HandHeart } from 'lucide-react'

// Mock user data
const userData = {
  name: 'Prajnika Neela',
  title: 'Marketing Director at GrowthCo',
  bio: 'Passionate about growth marketing and learning from failures. Believer in vulnerable leadership and continuous improvement.',
  avatar: 'https://images.unsplash.com/photo-1548229591-a7feaad39518?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdXRoZW50aWMlMjBwcm9mZXNzaW9uYWwlMjB3b21hbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc1ODQ4MDA1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  joinedDate: 'March 2024',
  stats: {
    storiesShared: 12,
    lessonsLearned: 18,
    supportGiven: 156,
    followers: 234
  },
  recentFailures: [
    {
      id: '1',
      content: 'Pitched what I thought was a brilliant campaign to our biggest client. They not only rejected it...',
      date: '2 days ago',
      reactions: { resilient: 89, lesson: 156, support: 92 }
    },
    {
      id: '2',
      content: 'Completely misread the market for our Q3 product launch. Spent 3 months on messaging that...',
      date: '1 week ago',
      reactions: { resilient: 67, lesson: 134, support: 45 }
    },
    {
      id: '3',
      content: 'Made a terrible hiring decision that set our team back months. Ignored red flags during...',
      date: '2 weeks ago',
      reactions: { resilient: 123, lesson: 98, support: 78 }
    }
  ]
}

export function ProfilePage() {
  const [activeTab, setActiveTab] = useState<'failures' | 'about'>('failures')

  return (
    <div className="min-h-screen bg-white pb-20 text-black">
      {/* Header */}
      <div className="border-b border-pink-200">
        {/* Cover area with gradient */}
        <div className="h-32 bg-gradient-to-r from-[#ff99aa] to-[#ffb6c1]"></div>
        
        {/* Profile info */}
        <div className="px-4 pb-4">
          <div className="flex items-end space-x-4 -mt-16">
            <Avatar className="w-24 h-24 border-4 border-white">
              <AvatarImage src={userData.avatar} alt={userData.name} />
              <AvatarFallback>{userData.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
            </Avatar>
            <div className="flex-1 pt-16">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-xl font-semibold text-black">{userData.name}</h1>
                  <p className="text-black/70">{userData.title}</p>
                </div>
                <Button variant="outline" size="sm" className="border-pink-300 text-black">
                  <Edit3 className="w-4 h-4 mr-2 text-pink-600" />
                  Edit
                </Button>
              </div>
            </div>
          </div>

          <div className="mt-4">
            <p className="text-black/80 mb-3">{userData.bio}</p>
            
            <div className="flex items-center text-sm text-black/70 mb-4">
              <Calendar className="w-4 h-4 mr-1 text-pink-600" />
              Joined {userData.joinedDate}
            </div>

            {/* Stats */}
            <div className="flex space-x-6">
              <div className="text-center">
                <div className="text-lg font-semibold text-black">{userData.stats.storiesShared}</div>
                <div className="text-xs text-black/70">Stories</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-black">{userData.stats.lessonsLearned}</div>
                <div className="text-xs text-black/70">Lessons</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-black">{userData.stats.supportGiven}</div>
                <div className="text-xs text-black/70">Support Given</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-black">{userData.stats.followers}</div>
                <div className="text-xs text-black/70">Followers</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-pink-200 px-4">
        <div className="flex space-x-8">
          <button
            onClick={() => setActiveTab('failures')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'failures' 
                ? 'border-pink-500 text-pink-600' 
                : 'border-transparent text-black/70'
            }`}
          >
            My Failures
          </button>
          <button
            onClick={() => setActiveTab('about')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'about' 
                ? 'border-pink-500 text-pink-600' 
                : 'border-transparent text-black/70'
            }`}
          >
            About
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {activeTab === 'failures' && (
          <div className="space-y-4">
            {userData.recentFailures.map((failure) => (
              <Card key={failure.id} className="bg-[#fff0f6] border-pink-200 text-black">
                <CardContent className="p-4">
                  <p className="text-black/80 mb-3">{failure.content}</p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-black/70">{failure.date}</span>
                    
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center space-x-1">
                        <Flame className="w-4 h-4 text-pink-600" />
                        <span className="text-sm text-black/70">{failure.reactions.resilient}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Lightbulb className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm text-black/70">{failure.reactions.lesson}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <HandHeart className="w-4 h-4 text-pink-500" />
                        <span className="text-sm text-black/70">{failure.reactions.support}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {activeTab === 'about' && (
          <div className="space-y-6">
            <Card className="bg-[#fff0f6] border-pink-200 text-black">
              <CardContent className="p-4">
                <h3 className="font-medium text-black mb-3">About</h3>
                <p className="text-black/80 leading-relaxed">
                  I believe that sharing our failures is just as important as celebrating our successes. 
                  Through vulnerability and openness about our mistakes, we create stronger connections 
                  and learn faster as a community.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#fff0f6] border-pink-200 text-black">
              <CardContent className="p-4">
                <h3 className="font-medium text-black mb-3">Core Values</h3>
                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-[#ff99aa] text-black">Vulnerability</Badge>
                  <Badge className="bg-[#ff99aa] text-black">Growth Mindset</Badge>
                  <Badge className="bg-[#ff99aa] text-black">Authenticity</Badge>
                  <Badge className="bg-[#ff99aa] text-black">Resilience</Badge>
                  <Badge className="bg-[#ff99aa] text-black">Community</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#fff0f6] border-pink-200 text-black">
              <CardContent className="p-4">
                <h3 className="font-medium text-black mb-3">Greatest Learnings</h3>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-pink-500 rounded-full mt-2"></div>
                    <p className="text-black/80">Failure is not the opposite of success; it's a stepping stone to it.</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-pink-500 rounded-full mt-2"></div>
                    <p className="text-black/80">The best leaders are those who can admit their mistakes and learn from them.</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-pink-500 rounded-full mt-2"></div>
                    <p className="text-black/80">Vulnerability in the workplace creates psychological safety for everyone.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}

