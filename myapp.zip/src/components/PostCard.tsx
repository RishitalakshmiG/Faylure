import { useState } from 'react'
import { motion, PanInfo } from 'motion/react'
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar'
import { Card, CardContent } from './ui/card'
import { Button } from './ui/button'
import { MessageCircle, MoreHorizontal, Flame, Lightbulb, HandHeart } from 'lucide-react'
import { ImageWithFallback } from './figma/ImageWithFallback'

interface Post {
  id: string
  author: {
    name: string
    title: string
    avatar: string
  }
  content: string
  lessonLearned?: string
  timeAgo: string
  reactions: {
    resilient: number
    lesson: number
    support: number
  }
  comments: number
  image?: string
}

interface PostCardProps {
  post: Post
  onSwipeRight: () => void
  onReaction: (type: 'resilient' | 'lesson' | 'support') => void
}

export function PostCard({ post, onSwipeRight, onReaction }: PostCardProps) {
  const [showReactions, setShowReactions] = useState(false)
  const [dragX, setDragX] = useState(0)

  const handleDrag = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    setDragX(info.offset.x)
    
    if (info.offset.x > 150) {
      // Show write post indicator
    } else if (info.offset.x < -150) {
      setShowReactions(true)
    }
  }

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (info.offset.x > 150) {
      onSwipeRight()
    } else if (info.offset.x < -150) {
      setShowReactions(true)
    } else {
      setShowReactions(false)
    }
    setDragX(0)
  }

  return (
    <div className="relative mb-4">
      <motion.div
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        onDrag={handleDrag}
        onDragEnd={handleDragEnd}
        className="relative z-10"
        style={{ x: dragX }}
      >
        <Card className="mx-4 shadow-sm bg-pink-50 text-black">
          <CardContent className="p-4">
            {/* Header */}
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-3">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={post.author.avatar} alt={post.author.name} />
                  <AvatarFallback>{post.author.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-medium text-black">{post.author.name}</h3>
                  <p className="text-sm text-black">{post.author.title}</p>
                  <p className="text-xs text-black">{post.timeAgo}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="text-pink-600 hover:text-pink-800">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </div>

            {/* Content */}
            <div className="mb-4">
              <p className="text-black leading-relaxed">{post.content}</p>
              
              {post.lessonLearned && (
                <div className="mt-3 p-3 bg-pink-50 rounded-lg border-l-4 border-pink-400">
                  <div className="flex items-center mb-1">
                    <Lightbulb className="w-4 h-4 text-pink-600 mr-2" />
                    <span className="text-sm font-medium text-pink-800">Lesson Learned</span>
                  </div>
                  <p className="text-sm text-pink-700">{post.lessonLearned}</p>
                </div>
              )}
            </div>

            {/* Image if present */}
            {post.image && (
              <div className="mb-4 rounded-lg overflow-hidden">
                <ImageWithFallback 
                  src={post.image} 
                  alt="Post image"
                  className="w-full h-48 object-cover"
                />
              </div>
            )}

            {/* Reactions */}
            <div className="flex items-center justify-between pt-3 border-t border-pink-300">
              <div className="flex items-center space-x-4">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="flex items-center space-x-1 text-pink-600 hover:text-pink-800"
                  onClick={() => onReaction('resilient')}
                >
                  <Flame className="w-4 h-4" />
                  <span className="text-sm">{post.reactions.resilient}</span>
                </Button>
                
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="flex items-center space-x-1 text-pink-600 hover:text-pink-800"
                  onClick={() => onReaction('lesson')}
                >
                  <Lightbulb className="w-4 h-4" />
                  <span className="text-sm">{post.reactions.lesson}</span>
                </Button>
                
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="flex items-center space-x-1 text-pink-600 hover:text-pink-800"
                  onClick={() => onReaction('support')}
                >
                  <HandHeart className="w-4 h-4" />
                  <span className="text-sm">{post.reactions.support}</span>
                </Button>
              </div>

              <Button variant="ghost" size="sm" className="flex items-center space-x-1 text-pink-600 hover:text-pink-800">
                <MessageCircle className="w-4 h-4" />
                <span className="text-sm">{post.comments}</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Reaction Overlay */}
      {showReactions && (
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          className="absolute right-4 top-1/2 transform -translate-y-1/2 z-20 bg-pink-50 rounded-full shadow-lg p-3 flex flex-col space-y-2"
        >
          <Button
            size="sm"
            variant="ghost"
            className="w-12 h-12 rounded-full bg-pink-50 hover:bg-pink-100"
            onClick={() => {
              onReaction('resilient')
              setShowReactions(false)
            }}
          >
            <Flame className="w-6 h-6 text-pink-600" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="w-12 h-12 rounded-full bg-pink-50 hover:bg-pink-100"
            onClick={() => {
              onReaction('lesson')
              setShowReactions(false)
            }}
          >
            <Lightbulb className="w-6 h-6 text-pink-600" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="w-12 h-12 rounded-full bg-pink-50 hover:bg-pink-100"
            onClick={() => {
              onReaction('support')
              setShowReactions(false)
            }}
          >
            <HandHeart className="w-6 h-6 text-pink-600" />
          </Button>
        </motion.div>
      )}

      {/* Swipe Indicators */}
      {dragX > 50 && (
        <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-5 text-pink-600">
          <motion.div
            initial={{ scale: 0.8, opacity: 0.5 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-lg"
          >
            ✍️ Write
          </motion.div>
        </div>
      )}
      
      {dragX < -50 && (
        <div className="absolute right-4 top-1/2 transform -translate-y-1/2 z-5 text-pink-600">
          <motion.div
            initial={{ scale: 0.8, opacity: 0.5 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-lg"
          >
            React
          </motion.div>
        </div>
      )}
    </div>
  )
}