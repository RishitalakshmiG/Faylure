import { useState } from 'react'
import { Button } from './ui/button'
import { Textarea } from './ui/textarea'
import { Card, CardContent } from './ui/card'
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar'
import { ArrowLeft, Image, Send } from 'lucide-react'
import { ImageWithFallback } from './figma/ImageWithFallback'

interface WritePostProps {
  onBack: () => void
  onSubmit: (post: { content: string; lessonLearned?: string; image?: string }) => void
}

export function WritePost({ onBack, onSubmit }: WritePostProps) {
  const [content, setContent] = useState('')
  const [lessonLearned, setLessonLearned] = useState('')
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Mock current user data
  const currentUser = {
    name: 'You',
    title: 'Your professional journey',
    avatar: 'https://images.unsplash.com/photo-1576558656222-ba66febe3dec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdCUyMHBvcnRyYWl0fGVufDF8fHx8MTc1ODQ0NTk4NHww&ixlib=rb-4.1.0&q=80&w=400'
  }

  const handleSubmit = async () => {
    if (!content.trim()) return
    
    setIsSubmitting(true)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    onSubmit({
      content: content.trim(),
      lessonLearned: lessonLearned.trim() || undefined,
      image: selectedImage || undefined
    })
    
    setIsSubmitting(false)
  }

  const handleImageUpload = () => {
    // In a real app, this would trigger a file picker
    // For demo, we'll just add a placeholder image
    setSelectedImage('https://images.unsplash.com/photo-1551434678-e076c223a692?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWlsdXJlJTIwc3VjY2Vzc3xlbnwxfHx8fDE3NTg0NzIyODF8MA&ixlib=rb-4.1.0&q=80&w=800')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center space-x-3">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold text-gray-900">Share Your Story</h1>
        </div>
        <Button 
          onClick={handleSubmit}
          disabled={!content.trim() || isSubmitting}
          className="bg-pink-600 hover:bg-pink-700 text-white"
        >
          {isSubmitting ? (
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <Send className="w-4 h-4 mr-2" />
              Post
            </>
          )}
        </Button>
      </div>

      <div className="p-4">
        <Card>
          <CardContent className="p-4">
            {/* User Info */}
            <div className="flex items-center space-x-3 mb-4">
              <Avatar className="w-12 h-12">
                <AvatarImage src={currentUser.avatar} alt={currentUser.name} />
                <AvatarFallback>You</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-medium text-gray-900">{currentUser.name}</h3>
                <p className="text-sm text-gray-600">{currentUser.title}</p>
              </div>
            </div>

            {/* Main Content */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Share your failure story
                </label>
                <Textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="What went wrong? How did it make you feel? Be honest and vulnerable - that's where the real growth happens..."
                  className="min-h-32 resize-none border-gray-200 focus:border-pink-500 focus:ring-pink-500"
                />
                <p className="text-xs text-gray-500 mt-1">
                  {content.length}/500 characters
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  What did you learn? (Optional)
                </label>
                <Textarea
                  value={lessonLearned}
                  onChange={(e) => setLessonLearned(e.target.value)}
                  placeholder="What insights did you gain? How would you approach it differently next time?"
                  className="min-h-24 resize-none border-gray-200 focus:border-pink-500 focus:ring-pink-500"
                />
              </div>

              {/* Image Upload */}
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
                {selectedImage ? (
                  <div className="relative">
                    <ImageWithFallback
                      src={selectedImage}
                      alt="Selected image"
                      className="w-full h-48 object-cover rounded-lg"
                    />
                    <Button
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={() => setSelectedImage(null)}
                    >
                      Remove
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="ghost"
                    onClick={handleImageUpload}
                    className="w-full h-24 border-none hover:bg-gray-100"
                  >
                    <div className="text-center">
                      <Image className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                      <p className="text-sm text-gray-600">Add an image (optional)</p>
                    </div>
                  </Button>
                )}
              </div>
            </div>

            {/* Tips */}
            <div className="mt-6 p-3 bg-pink-50 rounded-lg">
              <h4 className="text-sm font-medium text-pink-800 mb-2">💡 Tips for sharing</h4>
              <ul className="text-sm text-pink-700 space-y-1">
                <li>• Be specific about what happened</li>
                <li>• Focus on your emotions and reactions</li>
                <li>• Share what you learned or how you grew</li>
                <li>• Remember: vulnerability builds connection</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}