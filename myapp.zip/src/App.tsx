import { useState } from 'react'
import { HomeFeed } from './components/HomeFeed'
import { WritePost } from './components/WritePost'
import { CommunityPage } from './components/CommunityPage'
import { ProfilePage } from './components/ProfilePage'
import { NavigationBar } from './components/NavigationBar'

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'write' | 'community' | 'profile'>('home')

  const handleWritePost = () => {
    setActiveTab('write')
  }

  const handlePostSubmit = (post: { content: string; lessonLearned?: string; image?: string }) => {
    // In a real app, this would save the post to a backend
    console.log('New post submitted:', post)
    
    // Navigate back to home feed
    setActiveTab('home')
  }

  const handleBackFromWrite = () => {
    setActiveTab('home')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main Content */}
      {activeTab === 'home' && <HomeFeed onWritePost={handleWritePost} />}
      {activeTab === 'write' && (
        <WritePost 
          onBack={handleBackFromWrite}
          onSubmit={handlePostSubmit}
        />
      )}
      {activeTab === 'community' && <CommunityPage />}
      {activeTab === 'profile' && <ProfilePage />}

      {/* Navigation Bar - Hidden on write screen */}
      {activeTab !== 'write' && (
        <NavigationBar 
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />
      )}
    </div>
  )
}